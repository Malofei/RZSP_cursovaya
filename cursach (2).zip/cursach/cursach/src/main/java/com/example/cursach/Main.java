package com.example.cursach;
/**
 * Точка входа в приложение. Запускает приложение.
 */
public class Main {
    /**
     * Запускает приложение.
     * @param args Аргументы командной строки.
     */
    public static void main(String[] args) {
        GUI.main(args);
    }
}